<div class="wrap">
    <h1>Zoom Integration</h1>
    <p>Welcome to the Zoom Integration plugin.</p>
</div>